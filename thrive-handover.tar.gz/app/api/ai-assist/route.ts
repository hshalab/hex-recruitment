import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'
import { rateLimit } from '@/lib/rateLimit'

export const maxDuration = 30

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
)

export async function POST(request: NextRequest) {
  try {
    // Auth check: only authenticated users can use AI assist
    const authHeader = request.headers.get('authorization')
    const token = authHeader?.replace('Bearer ', '')
    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    const { data: { user }, error: authError } = await supabase.auth.getUser(token)
    if (authError || !user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Rate limit: max 10 requests per minute per IP
    const ip = request.headers.get('x-forwarded-for') || 'unknown'
    if (!rateLimit(`ai-assist:${ip}`, 10, 60000)) {
      return NextResponse.json({ error: 'Too many requests' }, { status: 429 })
    }

    const apiKey = process.env.ANTHROPIC_API_KEY
    if (!apiKey) {
      return NextResponse.json(
        { error: 'AI service not configured' },
        { status: 503 }
      )
    }

    const body = await request.json()
    const { type, data } = body

    let systemPrompt = ''
    let userPrompt = ''

    if (type === 'summary') {
      systemPrompt = 'You are a professional CV writer. Write a compelling, concise professional summary (3-4 sentences) for a job seeker. Use first person. Be specific and results-oriented. Do not use generic filler. Return only the summary text, no quotes or labels.'
      userPrompt = `Write a professional summary for someone with this background:
Name: ${data.name || 'Not specified'}
Current/Target Role: ${data.jobTitle || 'Not specified'}
Sector: ${data.sector || 'Not specified'}
Years of Experience: ${data.yearsExperience || 'Not specified'}
Key Skills: ${(data.skills || []).join(', ') || 'Not specified'}
Location: ${data.location || 'Not specified'}
${data.additionalContext ? `Additional context: ${data.additionalContext}` : ''}`
    } else if (type === 'experience') {
      systemPrompt = 'You are a professional CV writer. Write 4-5 concise, impactful bullet points describing responsibilities and achievements for a work experience entry. Start each bullet with a strong action verb. Include quantifiable results where possible. Return only the bullet points, each on a new line starting with •. No headers or labels.'
      userPrompt = `Write CV bullet points for this role:
Job Title: ${data.jobTitle || 'Not specified'}
Company: ${data.company || 'Not specified'}
Key Duties: ${data.keyDuties || 'Not specified'}
Duration: ${data.duration || 'Not specified'}
${data.additionalContext ? `Additional context: ${data.additionalContext}` : ''}`
    } else if (type === 'job-ad' || type === 'job-ad-enhance') {
      const isEnhance = type === 'job-ad-enhance'

      systemPrompt = isEnhance
        ? `You are a UK recruitment copywriter. The user will give you rough notes about a job. Write a compelling, professional job advertisement with these sections: About the Role, Key Responsibilities, What We're Looking For, What We Offer. Be concise and engaging. Respond ONLY with a valid JSON object in this exact format, no markdown, no extra text: {"description": "full html formatted job ad here"}`
        : `You are an expert UK hospitality recruitment copywriter. Write a compelling, professional UK job advertisement for the hospitality sector. Return ONLY a valid JSON object with these fields: title (string), description (string, HTML formatted with <p> and <ul>/<li> tags), requirements (string, HTML formatted), benefits (string, HTML formatted or empty string). No markdown fences, no extra text outside the JSON object.`

      if (isEnhance) {
        userPrompt = `Write a job ad from these notes:
Job Title: ${data.title || 'Not specified'}
Location: ${data.location || 'Not specified'}
Salary: ${data.salaryMin ? `£${data.salaryMin}${data.salaryMax ? ` - £${data.salaryMax}` : ''} per ${data.salaryPeriod || 'hour'}` : 'Competitive'}
Employment Type: ${data.employmentType || 'Full-time'}
${data.description || ''}`
      } else {
        userPrompt = `Write a job advertisement and return as JSON:
Job Title: ${data.title || 'Not specified'}
Company: ${data.company || 'Not specified'}
Location: ${data.location || 'Not specified'}
Salary: ${data.salaryMin ? `£${data.salaryMin}${data.salaryMax ? ` - £${data.salaryMax}` : ''} per ${data.salaryPeriod || 'hour'}` : 'Competitive'}
Employment Type: ${data.employmentType || 'Full-time'}
Work Type: ${data.workLocationType || 'In person'}
Category: ${data.category || 'Not specified'}

${data.bulletPoints ? `Key points to include:\n${data.bulletPoints}` : ''}
${data.companyDescription ? `About the company: ${data.companyDescription}` : ''}`
      }

      const aiResponse = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': apiKey,
          'anthropic-version': '2023-06-01',
        },
        body: JSON.stringify({
          model: 'claude-sonnet-4-6',
          max_tokens: 800,
          system: systemPrompt,
          messages: [{ role: 'user', content: userPrompt }],
        }),
      })

      if (!aiResponse.ok) {
        const errText = await aiResponse.text()
        console.error('Anthropic API error:', aiResponse.status, errText)
        return NextResponse.json({ error: `AI service error (${aiResponse.status}): ${errText}` }, { status: 502 })
      }

      const aiResult = await aiResponse.json()
      const rawText = aiResult.content?.[0]?.text || ''

      // Robust JSON extraction — try direct parse first, then regex fallback
      let jobAd: Record<string, string> | null = null
      try {
        jobAd = JSON.parse(rawText)
      } catch {
        const match = rawText.match(/\{[\s\S]*\}/)
        if (match) {
          try {
            jobAd = JSON.parse(match[0])
          } catch {
            // fall through to error below
          }
        }
      }

      if (!jobAd) {
        console.error('Failed to parse job-ad JSON:', rawText)
        return NextResponse.json({ error: 'AI returned invalid format' }, { status: 502 })
      }

      return NextResponse.json({ jobAd })
    } else {
      return NextResponse.json(
        { error: 'Invalid type.' },
        { status: 400 }
      )
    }

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 512,
        system: systemPrompt,
        messages: [{ role: 'user', content: userPrompt }],
      }),
    })

    if (!response.ok) {
      const errText = await response.text()
      console.error('Anthropic API error:', response.status, errText)
      return NextResponse.json(
        { error: `AI service error (${response.status}): ${errText}` },
        { status: 502 }
      )
    }

    const result = await response.json()
    const text = result.content?.[0]?.text || ''

    return NextResponse.json({ text })
  } catch (error) {
    console.error('AI assist error:', error)
    return NextResponse.json(
      { error: 'Failed to generate text' },
      { status: 500 }
    )
  }
}
