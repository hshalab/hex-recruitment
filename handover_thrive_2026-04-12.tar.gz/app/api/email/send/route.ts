import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'
import { sendEmail } from '@/lib/email'
import { rateLimit } from '@/lib/rateLimit'

// Template imports
import { welcomeEmail } from '@/emails/welcome'
import { newApplicationEmail } from '@/emails/new-application'
import { applicationStatusEmail } from '@/emails/application-status'
import { interviewScheduledEmail } from '@/emails/interview-scheduled'
import { interviewRescheduledEmail } from '@/emails/interview-rescheduled'
import { interviewConfirmedEmail } from '@/emails/interview-confirmed'
import { interviewCancelledEmail } from '@/emails/interview-cancelled'
import { trialEndingEmail } from '@/emails/trial-ending'
import { newMessageEmail } from '@/emails/new-message'
import { passwordResetEmail } from '@/emails/password-reset'
import { emailVerificationEmail } from '@/emails/email-verification'
import { activationDay1Email } from '@/emails/activation-day1'
import { activationDay3Email } from '@/emails/activation-day3'
import { activationDay7Email } from '@/emails/activation-day7'
import { activationDay14Email } from '@/emails/activation-day14'
import { activationDay30Email } from '@/emails/activation-day30'
import { candidateWelcomeEmail } from '@/emails/candidate-welcome'

export async function POST(req: Request) {
  try {
    // Auth check: allow authenticated users, cron jobs, and internal server calls
    const authHeader = req.headers.get('authorization')
    const internalSecret = req.headers.get('x-internal-secret')
    const cronSecret = process.env.CRON_SECRET

    const isCronCall = cronSecret && authHeader === `Bearer ${cronSecret}`
    const isInternalCall = cronSecret && internalSecret === cronSecret

    if (!isCronCall && !isInternalCall) {
      const token = authHeader?.replace('Bearer ', '')
      if (token) {
        const supabaseCheck = createClient(
          process.env.NEXT_PUBLIC_SUPABASE_URL!,
          process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
        )
        const { data: { user }, error: authError } = await supabaseCheck.auth.getUser(token)
        if (authError || !user) {
          return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
        }
      }
      // Calls without any auth header are allowed (client-side browser calls)
    }

    // Rate limit: max 5 requests per minute per IP
    const ip = req.headers.get('x-forwarded-for') || 'unknown'
    if (!rateLimit(`email-send:${ip}`, 5, 60000)) {
      return NextResponse.json({ error: 'Too many requests' }, { status: 429 })
    }

    const body = await req.json()
    let { to, type, data } = body

    if (!type) {
      return NextResponse.json({ error: 'Missing required field: type' }, { status: 400 })
    }

    // If no direct email, look up by user ID
    if (!to && data?.recipientUserId) {
      const supabaseAdmin = createClient(
        process.env.NEXT_PUBLIC_SUPABASE_URL!,
        process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
      )
      const { data: userData } = await supabaseAdmin.auth.admin.getUserById(data.recipientUserId)
      to = userData?.user?.email || null

      if (!to) {
        // Fallback: check candidate_profiles or employer_profiles
        const { data: profile } = await supabaseAdmin
          .from('candidate_profiles')
          .select('email')
          .eq('user_id', data.recipientUserId)
          .maybeSingle()
        to = profile?.email || null

        if (!to) {
          const { data: empProfile } = await supabaseAdmin
            .from('employer_profiles')
            .select('email')
            .eq('user_id', data.recipientUserId)
            .maybeSingle()
          to = empProfile?.email || null
        }
      }
    }

    if (!to) {
      return NextResponse.json({ error: 'No recipient email found' }, { status: 400 })
    }

    let email: { subject: string; html: string }

    switch (type) {
      case 'welcome':
        email = welcomeEmail(data.contactName || data.companyName, data.companyName)
        break
      case 'candidate_welcome':
        email = candidateWelcomeEmail(data.candidateName)
        break
      case 'new_application':
        email = newApplicationEmail(data.candidateName, data.jobTitle, data.company)
        break
      case 'application_status':
        email = applicationStatusEmail(data.status, data.companyName, data.jobTitle, data.candidateName, data.reason)
        break
      case 'interview_scheduled':
        email = interviewScheduledEmail(data.companyName, data.jobTitle, data.date, data.time, data.notes, data.meetingLink)
        break
      case 'interview_rescheduled':
        email = interviewRescheduledEmail(data.companyName, data.jobTitle, data.candidateName, data.date, data.time, data.interviewType, data.meetingLink)
        break
      case 'interview_confirmed':
        email = interviewConfirmedEmail(data.companyName, data.jobTitle, data.candidateName, data.date, data.time, data.interviewType)
        break
      case 'interview_cancelled':
        email = interviewCancelledEmail(data.companyName, data.jobTitle, data.candidateName, data.date)
        break
      case 'trial_ending':
        email = trialEndingEmail(data.companyName, data.daysLeft)
        break
      case 'new_message':
        email = newMessageEmail(data.senderName, data.messagePreview)
        break
      case 'password_reset':
        email = passwordResetEmail(data.resetUrl)
        break
      case 'email_verification':
        email = emailVerificationEmail(data.verifyUrl)
        break
      case 'activation_day1':
        email = activationDay1Email(data.companyName)
        break
      case 'activation_day3':
        email = activationDay3Email(data.companyName)
        break
      case 'activation_day7':
        email = activationDay7Email(data.companyName)
        break
      case 'activation_day14':
        email = activationDay14Email(data.companyName)
        break
      case 'activation_day30':
        email = activationDay30Email(data.companyName)
        break
      case 'raw':
        // Pre-rendered subject + html passed directly (used by cron jobs)
        email = { subject: data.subject, html: data.html }
        break
      default:
        return NextResponse.json({ error: `Unknown email type: ${type}` }, { status: 400 })
    }

    const result = await sendEmail(to, email.subject, email.html)

    if (!result.success) {
      console.error(`[Email API] Failed to send ${type} to ${to}:`, result.error)
      return NextResponse.json({ success: false, error: result.error }, { status: 500 })
    }

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error('[Email API] Error:', error.message)
    return NextResponse.json({ success: false, error: 'Failed to send email' }, { status: 500 })
  }
}
