import FeedbackWidget from '@/components/FeedbackWidget'
import SessionGuard from '@/components/SessionGuard'
import type { Metadata } from 'next'
import { Inter, Dancing_Script } from 'next/font/google'
import { Providers } from './providers'
import './globals.css'

const inter = Inter({ subsets: ['latin'] })
const dancingScript = Dancing_Script({
  subsets: ['latin'],
  variable: '--font-cursive',
  weight: ['400', '700'],
})

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://hexrecruitment.co.uk'

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: 'Hex | Talent Recruitment — Free UK Job Board for Employers',
    template: '%s | Hex | Talent Recruitment',
  },
  description: 'Post unlimited jobs free for 12 months. No agency fees. Search candidates, manage applications and schedule interviews — one platform for all UK sectors.',
  keywords: ['UK jobs', 'job board', 'recruitment', 'hospitality jobs', 'healthcare jobs', 'find a job UK', 'hire staff UK', 'Hex', 'talent recruitment'],
  authors: [{ name: 'Hex' }],
  creator: 'Hex',
  publisher: 'Hex',
  openGraph: {
    type: 'website',
    locale: 'en_GB',
    url: SITE_URL,
    siteName: 'Hex',
    title: 'Hex | Talent Recruitment — Free UK Job Board for Employers',
    description: 'Post unlimited jobs free for 12 months. No agency fees. Search candidates, manage applications and schedule interviews — one platform for all UK sectors.',
    images: [
      {
        url: '/opengraph-image',
        width: 1200,
        height: 630,
        alt: 'Hex — Talent Recruitment',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Hex | Talent Recruitment — Free UK Job Board for Employers',
    description: 'Post unlimited jobs free for 12 months. No agency fees. Search candidates, manage applications and schedule interviews — one platform for all UK sectors.',
    images: ['/opengraph-image'],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  alternates: {
    canonical: SITE_URL,
    languages: {
      'en-GB': SITE_URL,
    },
  },
  icons: {
    icon: '/icon.svg',
    apple: '/apple-touch-icon.png',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en-GB">
      <body className={`${inter.className} ${dancingScript.variable}`}>
        <Providers>
          <SessionGuard />
          {children}
          <FeedbackWidget />
        </Providers>
      </body>
    </html>
  )
}
